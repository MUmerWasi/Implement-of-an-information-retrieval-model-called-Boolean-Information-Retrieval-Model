Instructions

Dowload and Install Ananaconda
Run pip install jupyter on anaconda terminal
Install python extension on VS code
Open the specififc folder in vs code 
Run the cell